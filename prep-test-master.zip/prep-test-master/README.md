# Ruby Association Certified Ruby Programmer Examination

Sample questions for [Ruby Association Certified Ruby Programmer Examination](https://www.ruby.or.jp/en/certification/examination/)

* [Sample Questions for Silver](silver.md)
* [Sample Questions for Gold](gold.md)
